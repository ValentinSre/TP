Pour ouvrir le fichier Jupyter Notebook :

Si vous avez un environnement Jupyter installé sur votre machine, il suffit d'ouvrir le fichier pour le lire.

Sinon, suivez le protocole suivant, qui s'appuie sur la version Web de Jupyter.
- Rendez-vous à l'adresse https://jupyter.org/try
- Sélectionnez "Try Classic Notebook"
- Patientez le temps du chargement (quelques secondes)

Un fichier 'modèle' s'ouvre alors. 
- Cliquez sur File > Open (en haut à gauche)

Un nouvel onglet s'ouvre alors.
- Cliquez sur Upload (en haut à droite)
- Sélectionnez le fichier .ipynb, téléversez-le
- Ouvrez le fichier

Vous pouvez désormais tester les fonctions en exécutant directement les cellules contenant les démonstrations jointes
et/ou en ajoutant vous-même une cellule (+) et tapant votre code.